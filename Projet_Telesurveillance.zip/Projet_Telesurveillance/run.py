# -*- coding: utf-8 -*-
"""
Created on Thu Sep 30 11:42:14 2021

@author: nadee
"""

from app import app
app.run(debug = False, port = 8000, host='0.0.0.0')
#app.run(debug=True)

